function toggleProfileImageFullscreen() {
    const profileImageFullscreen = document.getElementById('profileImageFullscreen');
    profileImageFullscreen.style.display = profileImageFullscreen.style.display === 'block' ? 'none' : 'block';
}

function goToInfoPage(page) {
    window.location.href = page;
}
